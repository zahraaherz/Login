//
//  LoginApp.swift
//  Login
//
//  Created by Zahraa Herz on 28/03/2022.
//

import SwiftUI

@main
struct LoginApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
